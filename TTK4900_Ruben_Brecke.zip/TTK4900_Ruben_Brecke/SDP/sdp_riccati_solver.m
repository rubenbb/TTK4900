
function [H_stab_sol, time] = sdp_riccati_solver(A,B,Q,R,t_0,T,N,M,d_bound, dim)

% Symmetric real matrix, n x n
F_0 = sdpvar(dim, dim, 'symmetric', 'real');

% Symmetric complex matrix, n x n, k = 1,...,M
F_k = sdpvar(dim, dim, M, 'symmetric', 'complex');

omega = (2*pi)/T;
constraints = [];
time = linspace(t_0, t_0 + T, N);

%Find H, H_dot and Schur-complement L of R
for n = 1:N
    t = t_0 + (n-1)*(T/N);
    H = F_0;
    H_dot = 0;
    
    for m = 1:M
        % H for k>0
        H = H + exp(1i*m*omega*t)*F_k(:,:,m);
        H_dot = H_dot + (1i*m*omega)*exp(1i*m*omega*t)*F_k(:,:,m);
        
        % H for k<0, F_k = conj(F_k)
        H = H + exp(1i*(-m)*omega*t)*conj(F_k(:,:,m));
        H_dot = H_dot + (1i*(-m)*omega)*exp(1i*(-m)*omega*t)*conj(F_k(:,:,m));
    end
    
    % Find Schur complement L
    L = [H_dot+H*A(t)+A(t)'*H+Q(t) H*B(t); 
        B(t)'*H R];
    if dim == 2
        H_bound = [d_bound 0; 0 d_bound];
    elseif dim == 3
        H_bound = [d_bound 0 0; 0 d_bound 0; 0 0 d_bound];
    end
            
    
    % Create constraints
    constraints = [constraints, L >= 0];
    constraints = [constraints,  -H_bound <= H <= H_bound];
    
end

% Solve optimization problem, maximize tr(F_0(H))

obj = trace(F_0);
solution = optimize(constraints, -obj);
opt_F_0 = value(F_0);
opt_F_k = value(F_k);
if solution.problem ~= 0
    solution.info
    yalmiperror(solution.problem)
end

H_stab_sol = zeros(dim,dim,N);
for n = 1:N
    H_stab_sol(:,:,n) = opt_F_0;
    t = t_0 + (n-1)*(T/N);
    
    for m = 1:M
        H_stab_sol(:,:,n) = H_stab_sol(:,:,n) + exp(1i*m*omega*t)*opt_F_k(:,:,m) + exp(1i*(-m)*omega*t)*conj(opt_F_k(:,:,m));
    end
end

end


