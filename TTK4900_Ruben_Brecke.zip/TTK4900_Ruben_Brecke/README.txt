% To run the MATLAB script:


% Install SDPT3 for MATLAB: https://www.math.cmu.edu/~reha/sdpt3.html
% Install YALMIP for MATLAB: https://yalmip.github.io/

% The SDP folder must be in the MATLAB path


% Open ButterflyRobot.m
% Run the following in the terminal: object = ButterflyRobot(false)
%	This runs creates an object which can be run in Simulink.
%	To run the BVP part, use object = ButterflyRobot(true)
%	This will solve the BVP using BVP5C

% Open Simulink and run.
% Go back to termnial once Simulink is done, and write object.create_plots(out)
% Where the "out" object comes from Simulink