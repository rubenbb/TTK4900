
classdef ButterflyRobot
    
    properties
        m_b = 3.0e-3;           % Mass of the ball
        m_b_pert = 3.0e-3;
        J_b = 5.48e-7;          % Moment of inertia of ball
        J_b_pert = 5.6444e-7; 
        J_f = 1.581e-3;         % Moment of inertia of frame    
        J_f_pert = 1.62843e-3;
        grav_vec = [0 9.81 0];% Gravity vector
        grav = 9.81;
        %R_b = 16.55e-3;         % Radius of the ball
        r_f = 12.5e-3;          % Half the distance between the two plates of the frame
        R_b = sqrt(16.55e-3^2 - 12.5e-3^2);% Effective rolling radius of the ball
        R_b_pert = sqrt(18.205e-3^2 - 17.75e-3^2);
        k_hat = [0;0;1];        % Z-direction vector
        a = 0.1095;             % Coefficient describing the shape of the frame
        b = 0.0405;             % Coefficient describing the shape of the frame
        c = 0.49;               % Coefficient used in the VHC
        B = [1;0];              % Coupling matrix
        B_an = [0 1];           % Anniholation matrix
        phi_approx;   
        delta;
        tau;
        kappa_frame;
        g_fun;
        dg_fun;
        ddg_fun;
        normal_vector;
        rho;
        length_rho;
        ds;
        dds;
        dsf;
        ddsf;
        kappa;
        R; 
        diff_R;
        Theta;
        d_Theta;
        dd_Theta;
        phi_;
        A_transverse;
        B_transverse;
        Gamma = 1;
        function_for_dphi;
        Q = @(t)[20 0 0;0 20 0;0 0 20];
        X;
        phi_test;
        function_for_X;
        x_sim;
        F_fac;
        L_fac;
        A_cl;
        F_0;
        A1;A2;A3;A4;A5;A6;A7;A8;A9;
        sol_1; sol_2; sol_3; sol_4; sol_5; sol_6; sol_7; sol_8; sol_9;
        SL;
    end
    
    methods
        
        function object = ButterflyRobot(selector)
            
            %% Get approximate of phi
            delta_vec = @(phi) (object.a - object.b*cos(2*phi))*[sin(phi); cos(phi); 0];
            tau_vec = @(phi) ((2*object.b*sin(2*phi))*[sin(phi); cos(phi); 0] + ...
                (object.a - object.b*cos(2*phi))*[cos(phi); -sin(phi); 0])/(sqrt(sum((2*object.b*sin(2*phi)*[sin(phi);cos(phi);0] + ...
                (object.a - object.b*cos(2*phi))*[cos(phi);-sin(phi);0]).^2)));
            
            range_for_functions = linspace(0,2*pi,100000);
            
            function_g = @(x) atan2([1 0 0]*delta_vec(x) - object.R_b*[0 1 0]*tau_vec(x), ...
                                [0 1 0]*delta_vec(x)+object.R_b*[1 0 0]*tau_vec(x));
            res_fun_g = zeros(length(range_for_functions),1);
            res_fun_dg = zeros(length(range_for_functions),1);
            for i = 1:length(range_for_functions)
                res_fun_g(i) = function_g(range_for_functions(i));
            end
            res_fun_g = unwrap(res_fun_g);
            k = spline(res_fun_g,range_for_functions);
            result_spline = @(x)ppval(k,mod(x,2*pi));
            object.phi_approx = result_spline;

      
            %% Define parameters
            syms theta phi varphi
            
            
            % Delta
            delta = (object.a - object.b*cos(2*phi))*[sin(phi); cos(phi); 0];
            object.delta = matlabFunction(delta);
            
            tau = (2*object.b*sin(2*phi)*[sin(phi); cos(phi); 0] + (object.a - object.b*cos(2*phi))*[cos(phi); -sin(phi); 0])/...
                sqrt((2*object.b*sin(2*phi)*sin(phi) + (object.a - object.b*cos(2*phi))*cos(phi))^2 +  ...
                (2*object.b*sin(2*phi)*cos(phi) - (object.a - object.b*cos(2*phi))*sin(phi))^2);
            object.tau = matlabFunction(tau);
            
            
            b = object.b;
            a = object.a;
            kappa_frame = ((2*b*sin(2*phi)*sin(phi)+(a-b*cos(2*phi))*cos(phi))*(4*b*cos(2*phi)*cos(phi)-4*b*sin(2*phi)*sin(phi)-(a-b*cos(2*phi))*cos(phi)) - ...
                (4*b*cos(2*phi)*sin(phi) + 4*b*sin(2*phi)*cos(phi) - (a-b*cos(2*phi))*sin(phi))*(2*b*sin(2*phi)*cos(phi)-(a-b*cos(2*phi))*sin(phi)))/...
                (sqrt((2*b*sin(2*phi)*sin(phi)+(a-b*cos(2*phi))*cos(phi))^5 + ...
                (2*b*sin(2*phi)*cos(phi)-(a-b*cos(2*phi))*sin(phi))^5));
            object.kappa_frame = matlabFunction(kappa_frame);
            
            % Varphi
            g = atan2([1 0 0]*delta - object.R_b*[0 1 0]*tau,[0 1 0]*delta + object.R_b*[1 0 0]*tau);
      
            dg = diff(g,phi);
            ddg = diff(dg,phi);
            object.g_fun = matlabFunction(g);
            object.dg_fun = matlabFunction(dg);
            object.ddg_fun = matlabFunction(ddg);
            
            % Rho
            rho = delta + object.R_b*[[0 -1 0]*tau;[1 0 0]*tau;0];

            object.normal_vector = matlabFunction([[0 -1 0]*tau;[1 0 0]*tau;0]);
            object.rho = matlabFunction(rho);
            object.length_rho = matlabFunction(norm(rho));
            
            % s
            ds = norm(diff(rho,phi))/dg;
            dds = diff(rho,phi)'*diff(rho,phi,phi)/(norm(diff(rho,phi))*dg^2) - norm(diff(rho,phi))*ddg/dg^3;
            %dds = dot(diff(rho, phi), diff(rho, phi, phi))/(norm(diff(rho, phi, phi)))*1/dg - norm(diff(rho, phi))*ddg/dg^2;
            object.ds = matlabFunction(ds);
            object.dds = matlabFunction(dds);
            
            % s_f
            dsf = norm(diff(delta,phi))/dg;
            ddsf = diff(delta,phi)'*diff(delta,phi,phi)/norm(diff(delta,phi))/dg^2-norm(diff(delta,phi))*ddg/dg^3;
            object.dsf = matlabFunction(dsf);
            object.ddsf = matlabFunction(ddsf);
            
            % Kappa
            kappa = diff(rho,phi,phi)/dg^2/ds^2;
            object.kappa = matlabFunction(kappa);
            
            % R - Rotation matrix
            R = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];
            object.R = matlabFunction(R);
            object.diff_R = matlabFunction([-sin(theta) -cos(theta) 0;cos(theta) -sin(theta) 0;0 0 0]);
            
            
            %% Theta / varphi
            
            syms varphi

            % Gustav Theta
            a= -6.023940e+01; b= 9.115470e-03; c= 1.941337e-03; d= 1.731620e-03; e= 7.253528e-04;
            Theta = a*atan(b*sin(2*varphi)+c*sin(4*varphi)+d*sin(6*varphi)+e*sin(8*varphi))+varphi;
            d_Theta = diff(Theta,varphi);
            dd_Theta = diff(Theta,varphi,varphi);
            
            % Define Theta/d_Theta/dd_Theta in object
            object.Theta = matlabFunction(Theta);
            object.d_Theta = matlabFunction(d_Theta);
            object.dd_Theta = matlabFunction(dd_Theta);

            %% Simulate ABG (If selector = 0)

                options = odeset('RelTol', 1e-5, 'AbsTol', 1e-6);
                t_0 = 0; t_end = 10; N_sim = 100000;
                t_span = linspace(t_0, t_end, N_sim);
                
                
                x1 = [0];
                x2 = [1.17];
                figure
                hold on
                for i = 1:length(x1)
                    for j = 1:length(x2)
                        x_0 = [x1(i); x2(j)];
                        [t, x_sim] = ode23(@(t, y) ABG_dyn(object, y), t_span, x_0, options);
                        object.x_sim = x_sim;
                        plot(x_sim(:,1), x_sim(:,2));
                    end
                end
                hold off
                xlabel('$\varphi$','interpreter','latex')
                ylabel('$\dot{\varphi}$','interpreter','latex')
                sgtitle('Reduced Dynamics');

                
                i = 1;
                phi_dot = [0 0];
                length(x_sim)
                while x_sim(i,1) <= pi
                    phi_dot(i,:) = x_sim(i,:);
                    i = i+1;
                    if i >= length(x_sim)
                        break
                    end
                end
                phi_dot(i,:) = x_sim(i,:);
                
                %% Interpolated 
                interpolation_for_dphi = @(x) interp1(phi_dot(:,1),phi_dot(:,2), x);
                object.function_for_dphi = @(phi) interpolation_for_dphi(mod(phi,pi));

                [A_trans, B_trans] = object.get_linearization(phi, object.function_for_dphi);          
                object.A_transverse = @(phi) A_trans(phi);
                object.B_transverse = @(phi) B_trans(phi);
                [X,phi] = sdp_riccati_solver(object.A_transverse, object.B_transverse, ...
                    object.Q, object.Gamma, 0, pi, 100, 40, 10000, 3);
                object.X = X;

                 
                 %% Interpolation for Riccati solution
                interpolation_for_X = @(x)[interp1(phi,reshape(X(1,1,:),1,length(X)),x) interp1(phi,reshape(X(1,2,:),1,length(X)),x) interp1(phi,reshape(X(1,3,:),1,length(X)),x);
                                          interp1(phi,reshape(X(2,1,:),1,length(X)),x) interp1(phi,reshape(X(2,2,:),1,length(X)),x) interp1(phi,reshape(X(2,3,:),1,length(X)),x);
                                          interp1(phi,reshape(X(3,1,:),1,length(X)),x) interp1(phi,reshape(X(3,2,:),1,length(X)),x) interp1(phi,reshape(X(3,3,:),1,length(X)),x);];
                object.function_for_X = @(x) interpolation_for_X(mod(x,pi));
                
                
                
                
                
            if selector == true
                object.A_cl = object.find_Acl();
                A = object.A_cl;
            
                object.A1 = @(t) ([1 0 0]*A(t))*[1;0;0];
                object.A2 = @(t) ([1 0 0]*A(t))*[0;1;0];
                object.A3 = @(t) ([1 0 0]*A(t))*[0;0;1];
            
                object.A4 = @(t) ([0 1 0]*A(t))*[1;0;0];
                object.A5 = @(t) ([0 1 0]*A(t))*[0;1;0];
                object.A6 = @(t) ([0 1 0]*A(t))*[0;0;1];
            
                object.A7 = @(t) ([0 0 1]*A(t))*[1;0;0];
                object.A8 = @(t) ([0 0 1]*A(t))*[0;1;0];
                object.A9 = @(t) ([0 0 1]*A(t))*[0;0;1];
            
            
                % Calculate FL factorization
                solution = object.find_FL_fac();
                object.sol_1 = solution(1, :);
                object.sol_2 = solution(2, :);
                object.sol_3 = solution(3, :);
                object.sol_4 = solution(4, :);
                object.sol_5 = solution(5, :);
                object.sol_6 = solution(6, :);
                object.sol_7 = solution(7, :);
                object.sol_8 = solution(8, :);
                object.sol_9 = solution(9, :);
                object.SL = object.calc_stm();
            end
            
        end
        
        
        function dx = ABG_dyn(object, x)
            varphi = x(1);
            d_varphi = x(2);

            [alpha, beta, gamma] = object.get_ABG(varphi);
            dd_varphi = -(beta*d_varphi^2 + gamma)/alpha;
            
            dx = [d_varphi; dd_varphi];
        end
        
        function [alpha, beta, gamma] = get_ABG(object, varphi)
            rhoxtau = [0 0 1]*cross(object.get_rho(varphi),object.get_tau(varphi));
            rhodottau = object.get_rho(varphi)'*object.get_tau(varphi);
            ds_ = object.get_ds(varphi); dsf_ = object.get_dsf(varphi);
            dds_ = object.get_dds(varphi); ddsf_ = object.get_ddsf(varphi);
            JRm = object.J_b/object.R_b/object.m_b;
            
            alpha = object.m_b*((ds_*rhoxtau-dsf_*JRm)*object.get_d_Theta(varphi)+ds_^2+dsf_^2*JRm/object.R_b);
            beta = object.m_b*((ds_*rhoxtau-dsf_*JRm)*object.get_dd_Theta(varphi)-rhodottau*ds_*object.get_d_Theta(varphi)^2 ...
                + ds_*dds_ + dsf_*ddsf_*JRm/object.R_b);
            gamma = object.m_b*[0 object.grav 0]*object.R(object.get_Theta(varphi))*object.get_tau(varphi)*ds_;
              
              Rot = @(x) [cos(x) -sin(x) 0; sin(x) cos(x) 0; 0 0 1];

              %alpha = object.m_b*object.get_ds(varphi)*((cross(object.get_rho(varphi), object.get_tau(varphi)) - object.J_b/(object.m_b*object.R_b))*object.get_d_Theta(varphi) + ...
              %    (1 + object.J_b/(object.m_b*object.R_b^2))*object.get_ds(varphi));
              
              %beta = object.m_b*object.get_ds(varphi)*((cross(object.get_rho(varphi), object.get_tau(varphi)) - object.J_b/(object.m_b*object.R_b))*object.get_dd_Theta(varphi) - ...
              %    dot(object.get_tau(varphi), object.get_rho(varphi))*object.get_d_Theta(varphi)^2 + (1 + object.J_b/(object.m_b*object.R_b^2))*object.get_dds(varphi));
              
              %gamma = object.m_b*object.get_ds(varphi)*[0 9.81 0]*Rot(object.get_Theta(varphi))*object.get_tau(varphi);
              
%               alpha = object.get_ds(varphi)*(dot(object.m_b*[0;0;1], cross(object.get_rho(varphi), object.get_tau(varphi))) - ...
%                   object.J_b/object.R_b)*object.get_d_Theta(varphi) + object.get_ds(varphi)^2*(object.m_b + object.J_b/(object.R_b^2));
%               beta = object.get_ds(varphi)*(dot(object.m_b*[0;0;1], cross(object.get_rho(varphi), object.get_tau(varphi))) - ...
%                   object.J_b/object.R_b)*object.get_dd_Theta(varphi) - object.m_b*dot(object.get_ds(varphi)*object.get_tau(varphi), object.get_rho(varphi))*object.get_d_Theta(varphi)^2 + ...
%                   object.get_ds(varphi)*object.get_dds(varphi)*(object.m_b + object.J_b/(object.R_b^2));
%               gamma = object.m_b*dot(object.get_ds(varphi)*[0 9.81 0], Rot(object.get_Theta(varphi))*object.get_tau(varphi));
              
              

        end
                
        
        function rho = get_rho(object, varphi)
            rho = object.rho(object.phi_approx(varphi));
        end
        function l_rho = get_l_rho(object, varphi)
            l_rho = object.length_rho(object.phi_approx(varphi));
        end
        function tau = get_tau(object, varphi)
            tau = object.tau(object.phi_approx(varphi));
        end
        function kappa = get_kappa(object, varphi)
            kappa = object.kappa(object.phi_approx(varphi));
        end     
        function ds = get_ds(object, varphi)
            ds = object.ds(object.phi_approx(varphi));
        end
        function dsf = get_dsf(object, varphi)
            dsf = object.dsf(object.phi_approx(varphi));
        end
        function dds = get_dds(object, varphi)
            dds = object.dds(object.phi_approx(varphi));
        end       
        function ddsf = get_ddsf(object, varphi)
            ddsf = object.ddsf(object.phi_approx(varphi));
        end 
        function Theta = get_Theta(object, varphi)
            %Theta = object.Theta(object.phi_approx(varphi));
            Theta = object.Theta(varphi);
        end
        function d_Theta = get_d_Theta(object, varphi)
            %d_Theta = object.d_Theta(object.phi_approx(varphi));
            d_Theta = object.d_Theta(varphi);
        end
        function dd_Theta = get_dd_Theta(object, varphi)
            %dd_Theta = object.dd_Theta(object.phi_approx(varphi));
            dd_Theta = object.dd_Theta(varphi);
        end
        
        
        function M = get_M(object, q)
            varphi = q(2);
            rhoxtau = [0 0 1]*cross(object.get_rho(varphi), object.get_tau(varphi));
            
            m11 = object.get_l_rho(varphi)^2 + object.J_f/object.m_b + object.J_b/object.m_b;
            m12 = object.get_ds(varphi)*rhoxtau - object.get_dsf(varphi)*object.J_b/object.m_b/object.R_b;
            m22 = object.get_ds(varphi)^2 + object.get_dsf(varphi)^2*object.J_b/object.m_b/object.R_b^2;
            
%             m11 = object.J_f + object.J_b + object.m_b*
            
            M =   object.m_b*[m11 m12; m12 m22];
        end
        function C = get_C(object, q, dq)
            varphi = q(2);
            ds = object.get_ds(varphi);
            dsf = object.get_dsf(varphi);
            dds = object.get_dds(varphi);
            ddsf = object.get_ddsf(varphi);
            rhoxtau = [0 0 1]*cross(object.get_rho(varphi), object.get_tau(varphi));
            taudotrho = object.get_tau(varphi)'*object.get_rho(varphi);
            rhoxkappa = [0 0 1]*cross(object.get_rho(varphi),object.get_kappa(varphi));
            c11 = object.m_b*taudotrho*ds*dq(2);
            
            c12 = object.m_b*(taudotrho*ds*dq(1) ...
                +(dds*rhoxtau-ddsf*object.J_b/object.m_b/object.R_b ...
                +ds^2*rhoxkappa)*dq(2));
            
            c21 = -object.m_b*ds*taudotrho*dq(1);
            
            c22 = object.m_b*(ds*dds+dsf*ddsf*object.J_b/object.R_b^2/object.m_b)*dq(2);
            
            C = [c11 c12;
                 c21 c22];
        end
        function G = get_G(object, q)
            varphi = q(2);
            G = [object.m_b*[0;object.grav;0]'*object.diff_R(q(1))*object.get_rho(varphi);
                 object.m_b*[0;object.grav;0]'*object.R(q(1))*object.get_tau(varphi)*object.get_ds(varphi)];
        end
        
        % Perturber system matrices
        function M = get_M_pert(object, q)
            varphi = q(2);
            rhoxtau = [0 0 1]*cross(object.get_rho(varphi), object.get_tau(varphi));
            
            m11 = object.get_l_rho(varphi)^2 + object.J_f_pert/object.m_b_pert + object.J_b_pert/object.m_b_pert;
            m12 = object.get_ds(varphi)*rhoxtau - object.get_dsf(varphi)*object.J_b_pert/object.m_b_pert/object.R_b;
            m22 = object.get_ds(varphi)^2 + object.get_dsf(varphi)^2*object.J_b_pert/object.m_b_pert/object.R_b^2;
            
%             m11 = object.J_f + object.J_b + object.m_b*
            
            M =   object.m_b_pert*[m11 m12; m12 m22];
        end 
        function C = get_C_pert(object, q, dq)
            varphi = q(2);
            ds = object.get_ds(varphi);
            dsf = object.get_dsf(varphi);
            dds = object.get_dds(varphi);
            ddsf = object.get_ddsf(varphi);
            rhoxtau = [0 0 1]*cross(object.get_rho(varphi), object.get_tau(varphi));
            taudotrho = object.get_tau(varphi)'*object.get_rho(varphi);
            rhoxkappa = [0 0 1]*cross(object.get_rho(varphi),object.get_kappa(varphi));
            c11 = object.m_b_pert*taudotrho*ds*dq(2);
            
            c12 = object.m_b_pert*(taudotrho*ds*dq(1) ...
                +(dds*rhoxtau-ddsf*object.J_b_pert/object.m_b_pert/object.R_b ...
                +ds^2*rhoxkappa)*dq(2));
            
            c21 = -object.m_b_pert*ds*taudotrho*dq(1);
            
            c22 = object.m_b_pert*(ds*dds+dsf*ddsf*object.J_b_pert/object.R_b^2/object.m_b_pert)*dq(2);
            
            C = [c11 c12;
                 c21 c22];
        end
        
        function a = alpha_beta_gamma(object, varphi)
            rhoxtau = [0 0 1]*cross(object.get_rho(varphi),object.get_tau(varphi));
            rhodottau = object.get_rho(varphi)'*object.get_tau(varphi);
            ds_ = object.get_ds(varphi); dsf_ = object.get_dsf(varphi);
            dds_ = object.get_dds(varphi); ddsf_ = object.get_ddsf(varphi);
            JRm = object.J_b/object.R_b/object.m_b;
            
            alpha = object.m_b*((ds_*rhoxtau-dsf_*JRm)*object.get_d_Theta(varphi)+ds_^2+dsf_^2*JRm/object.R_b);
            beta = object.m_b*((ds_*rhoxtau-dsf_*JRm)*object.get_dd_Theta(varphi) - rhodottau*ds_*object.get_d_Theta(varphi)^2 ...
                + ds_*dds_ + dsf_*ddsf_*JRm/object.R_b);
            gamma = object.m_b*[0 object.grav 0]*object.R(object.get_Theta(varphi))*object.get_tau(varphi)*ds_;
            
            a = [alpha;beta;gamma];
%                [alpha, beta, gamma] = object.get_ABG(varphi);
%                a = [alpha;beta;gamma];
        end
        function g = get_g_w_y_on_trajectory(object, varphi, d_varphi)
            rhoxtau = [0 0 1]*cross(object.get_rho(varphi),object.get_tau(varphi));
            g_w = -object.m_b*(object.get_ds(varphi)*rhoxtau - object.get_dsf(varphi)*object.J_b/object.m_b/object.R_b);
            g_y_dot = object.m_b*object.get_ds(varphi)*object.tau(varphi)'*...
                object.rho(varphi)*(2*object.get_d_Theta(varphi)*d_varphi);
            g_y = -object.get_ds(varphi)*object.m_b*object.grav*[cos(object.get_Theta(varphi)) -sin(object.get_Theta(varphi)) 0]*object.get_tau(varphi);
            g = [g_w;g_y_dot;g_y];
        end
        function [A, B] = get_linearization(object, phi, phi_dot)
                abg = @(x)object.alpha_beta_gamma(x);
                gwy = @(x)object.get_g_w_y_on_trajectory(x, phi_dot(x));
                A = @(x)[0 1 0;
                         0 0 0;
                        [0 0 1]*gwy(x)/([1 0 0]*abg(x)) [0 1 0]*gwy(x)/([1 0 0]*abg(x)) ([0 0 1]*abg(x) - ...
                        [0 1 0]*abg(x)*phi_dot(x)^2)/([1 0 0]*abg(x))/phi_dot(x)];
                B = @(x)[0;1;[1 0 0]*gwy(x)/([1 0 0]*abg(x))];
        end
        
        function w = get_w(object, riccati_solution, q, epsilon)
            w = -1/(object.Gamma)*object.B_transverse(q(2))'*riccati_solution*epsilon;
        end
        function ddq = get_dynamics(object, q, dq, u)
            M = object.get_M(q);
            C = object.get_C(q,dq);
            G = object.get_G(q);
            ddq = (M^-1*(-C*dq-G+[u;0]));
        end
        function epsilon = get_epsilon(object, q, dq)
            epsilon = [q(1) - object.get_Theta(q(2));
                dq(1)-object.get_d_Theta(q(2))*dq(2);
                dq(2)-object.function_for_dphi(q(2))];
        end
        
        function y = saturation(object, x,delta)
            if abs(x) <= delta
                y= x*delta;
            else 
                y =sign(x);
            end


        end
        function u = get_u(object, q, dq, epsilon)
            %c_1 = 2; c_2 = 1; c_3 = 1;
            %sigma = c_1*epsilon(1) + c_2*epsilon(2) + c_3*epsilon(3);
            %riccati = object.function_for_X(q(2));
            %u_eq = -riccati(1)*epsilon(1) - riccati(2)*epsilon(2) - riccati(3)*epsilon(3) - 5*sign(sigma);
            %riccati = object.function_for_X(q(2));
            %sigma = riccati(1)*epsilon(1) + riccati(2)*epsilon(2) + riccati(3)*epsilon(3);
            %u_eq = -5*sign(sigma);
%             u_eq = -5*object.saturation(sigma, 1);

            %sigma = 1*epsilon(1) + 1*epsilon(2) + 1*epsilon(3);
            
            M = object.get_M([object.get_Theta(q(2)); q(2)]);
            C = object.get_C([object.get_Theta(q(2)); q(2)], [object.get_d_Theta(q(2))*dq(2); dq(2)]);
            G = object.get_G([object.get_Theta(q(2)); q(2)]);
            k = [1 0]*M*[object.get_d_Theta(q(2)); 1]/([object.get_d_Theta(q(2)) 1]*M*[0;1]);
            
            % U_EQ 
            a_mat = [0 0 1]*object.A_transverse(q(2));
            a31 = a_mat(1);
            a32 = a_mat(2);
            a33 = a_mat(3);
            b3 = [0 0 1]*object.B_transverse(q(2));
            g_func = (1/(1+b3))*(epsilon(1)*a31 + epsilon(2)*(1 + a32) + epsilon(3)*a33);
            riccati = object.function_for_X(q(2));
            
            %u_eq = 8*object.saturation(g_func*sign(epsilon(1) + epsilon(2) + epsilon(3)), 0.1);
            %u_eq = 1*g_func*object.saturation((riccati(1)*epsilon(1) + riccati(2)*epsilon(2) + riccati(3)*epsilon(3)), 1);
            
            
            % U_EQ SIGMA W/ RICATTI
            abg = object.alpha_beta_gamma(q(2));
            gwy = object.get_g_w_y_on_trajectory(q(2), dq(2));
            g1 = [0 0 1]*gwy/([1 0 0]*abg);
            g2 = [0 1 0]*gwy/([1 0 0]*abg);
            g3 = ([0 0 1]*abg - [0 1 0]*abg*dq(2)^2)/([1 0 0]*abg);
            g4 = [1 0 0]*gwy/([1 0 0]*abg);
            
            riccati = object.function_for_X(q(2));
            sigma = riccati(1)*epsilon(1) + riccati(2)*epsilon(2) + riccati(3)*epsilon(3);
            u_eq = 1/(g4)*(-g1*epsilon(1) - g2*epsilon(2) - g3*epsilon(3) - 4*object.saturation(sigma, 0.1));
            
            
            
            % HARD AZZ MF
            SL1 = [0, 0, -5.46236494174959e-05,-7.30921046895282e-05,-9.64656625979206e-05,-0.000124954430707033,-0.000159219039291055,-0.000200256874909510,-0.000249359730432348,-0.000308477623935794,-0.000380025017929682,-0.000466808052915047,-0.000572859099411545,-0.000703634939785640,-0.000865900918172054,-0.00107583665275499,-0.00135832791590355,-0.00174842531784924,-0.00227967809366051,-0.00300480229757482,-0.00373391624086379,-0.00375594814721352,-0.00263322791582889,-0.00122430039995378,-0.000318247015957778,0.000148683826202527,0.000385038295523701,0.000525551795897115,0.000598293129558156,0.000627223783800884,0.000679535774605171,0.000718645429552103,0.000747795782416237,0.000780151301469738,0.000854796670080666,0.000990136632188432,0.00107817087029944,0.00120791249505154,0.00145173530013284,0.00155289324633359,0.00161834048042990,0.00171847900883175,0.00184757507197432,0.00201923505746517,0.00210057829781157,0.00198879687303224,0.00177799398439288,0.00168865117534147,0.00161617976105326,0.00145522526889362,0.00125242063369096,0.00108428557172138,0.000918590126052821,0.000759221215211718,0.000637305976181693,0.000543459570693012,0.000472379663664592,0.000410609967356128,0.000355824502657530,0.000316006276384579,0.000277267285619927,0.000232741177316047,0.000206275312600551,0.000193422195568984,0.000168675245957763,0.000153372761510746,0.000149933290648182,0.000136819839838426,0.000122859265630693,9.78623149876511e-05,8.54324774982536e-05,7.62490262333989e-05,6.96810217185737e-05,5.53444788065395e-05,6.43630232100367e-05,8.52586053339649e-05,0.000131571470708543,0.000219057077542648,0.000330099081758347,0.000429210616448568,0.000523634020557106,0.000586069088097159,0.000602706970902256,0.000597845356911035,0.000598926120050892,0.000542366468329633,0.000569814303148419,0.000600480352120226,0.000743924104863733,0.000656170082950274,0.000621194803168853,0.00201075034281412,0.00156574929945899,0.00169977410832578,0.00174134895228446,0.00116375036947527,0.00104697525288519,0.00181097232058883,0.00154580384029953,0.000965302555304396,0.000483474199107058,0.000461632468974432,0.000803172324049284,0.00161189515837920,0.00134074181733623,0.00155277863024306,0.00165199538646757,0.00142095456309877,0.00203666698618125,0.00699346575959765,-0.00404059289092531,-0.00202583688382528,-0.00159622142500323,-0.00148277376156707,-0.00135043381758929,-0.00122000357006276,-0.00111724391502367,-0.00100612964674155,-0.000826363202557118,-0.000744914670857770,-0.00106367294419130,-0.000606325535013827,-0.000694806292808075,-0.000503329031746150,-0.000189238455090744,-0.000397444138300260,-0.000717846552425321,-0.000445853345746352,-0.000416273665308384,-0.000356291384332720,-0.000256232898095253,-0.000329170116747436,-0.000368540491554837,-0.000335366974403957,-0.000317047161357168,-0.000314559543134157,-0.000313641758435961,-0.000308153983705222,-0.000308660279011203,-0.000305856515038280,-0.000303946563861198,-0.000310897965014075,-0.000314840643826609,-0.000317585990442833,-0.000322073162668824,-0.000327390153674427,-0.000333280781429938,-0.000339772963758785,-0.000346656350351724,-0.000354574163728168,-0.000364180819803076,-0.000375487886245429,-0.000386810505541503,-0.000399027520409974,-0.000413491658671780,-0.000429176488778413,-0.000447115345441746,-0.000469223675980544,-0.000494459907201886,-0.000525632897474773,-0.000569168850508212,-0.000628782716341582,-0.000716680096802790,-0.000851489803622560,-0.00107422487098400,-0.00151143471880711,-0.00275699075833291,-0.0329552667962255,0.00291709302119633,0.00131730924312929,0.000818788997929637,0.000574102679011873,0.000430955525127065,0.000335783675355413,0.000266621004295089,0.000216977024594198,0.000180560330016870,0.000152583541157256,0.000130786461385212,0.000113003512818967,9.79035633538388e-05,8.58590116306372e-05,7.65360045573835e-05,6.91839040868081e-05,6.33988019110713e-05,5.91597521491581e-05,5.63966197328395e-05,5.42269278029785e-05,5.20720855546629e-05,4.94244521502421e-05,4.57921547179450e-05,4.18269970555584e-05,3.80274662994587e-05,3.37703762514374e-05,2.85234879224001e-05,2.20250865998976e-05,1.39981819235079e-05,4.67256758712023e-06,-5.70579051980997e-06,-1.75916447652428e-05,-3.15716818254700e-05];
            SL2 = [0, 0, -0.000184817420824867,-0.000180914961006628,-0.000178409599703562,-0.000176976261981521,-0.000176358240442469,-0.000176371159854311,-0.000176812282224027,-0.000177347696287672,-0.000177347308424129,-0.000175715611254513,-0.000170599379854579,-0.000159551000953443,-0.000138022179672650,-9.97464748348170e-05,-3.38874900251533e-05,7.64677568954593e-05,0.000250095156867508,0.000528186651166092,0.000886359599637630,0.00110700278592880,0.000933493472353496,0.000535900427522896,0.000213422870748440,8.18002220470100e-06,-0.000113429354135424,-0.000190009650241834,-0.000242676122532183,-0.000282430470976031,-0.000326316665730530,-0.000364828158212356,-0.000397101789893397,-0.000430488032000744,-0.000475388914375556,-0.000532281986601825,-0.000572340495733499,-0.000625592881917866,-0.000723973976756050,-0.000769888919844221,-0.000793601337543184,-0.000830246579339081,-0.000860487907408309,-0.000899863073267894,-0.000909971394765732,-0.000865950580247184,-0.000796257375544509,-0.000757895820057522,-0.000720447226267905,-0.000657089435586012,-0.000585607303072418,-0.000524351221124736,-0.000469914705660854,-0.000423664506728490,-0.000389752171924626,-0.000363685525458863,-0.000339248161122139,-0.000319095272344706,-0.000306000373243313,-0.000297045509112461,-0.000288976132373175,-0.000281844313654935,-0.000277474840730504,-0.000282149833001034,-0.000284185512906484,-0.000289912865114809,-0.000302164724002951,-0.000314715746754415,-0.000328268947530284,-0.000343121330448240,-0.000355591932699498,-0.000371699181029072,-0.000378267170420592,-0.000385046170271765,-0.000378159154871978,-0.000363399405677765,-0.000324279521797296,-0.000269836900629602,-0.000233143934914405,-0.000217672390326758,-0.000233337152397805,-0.000269093759771007,-0.000319954365825237,-0.000397569592870329,-0.000501260454158281,-0.000594792269373749,-0.000659599702061129,-0.000724897348362046,-0.000733289147422686,-0.000588176879975941,-0.000297555760079549,4.22884650779477e-05,-0.000149894474504297,-0.000243693894373523,-0.000363518854716098,-0.000502946856545570,-0.000506489650388016,-0.000330228785580970,-0.000458999391280275,-0.000758990246363634,-0.000881855090587569,-0.000959296132342413,-0.000754481224798332,-0.000326857892668854,-0.000274944677896767,-0.000265123462841860,-0.000392849799308669,-0.000528402923916662,-0.000660052496568665,-0.000996915225613683,-0.000412595386413201,-0.000379946497469957,-0.000338317094690154,-0.000329388195123754,-0.000275028086143949,-0.000270409174116031,-0.000248339740789343,-0.000222140828305895,-0.000295162078682068,-0.000206253001581555,0.000261745954180258,-1.41402129446818e-05,0.000117152480113238,-2.32768375935047e-05,-0.000317880199951127,-0.000138780869220777,0.000216499148396386,3.77795471796877e-05,3.95039207458632e-05,-3.11917419971779e-06,-0.000105785600185991,-4.55702030353580e-05,6.14888885412561e-06,-1.04406913846990e-05,-1.91646646927737e-05,-1.24009939957123e-05,-4.45920288834572e-06,-3.77949575439578e-06,6.92862000054288e-07,-2.78245693513190e-07,-4.00393427761728e-06,-2.37496554376362e-07,2.93408103372309e-06,4.72741582750853e-06,5.90793785072896e-06,1.09554889620584e-05,1.62901279765720e-05,2.06420894409457e-05,2.65753277929578e-05,3.25892506140366e-05,3.84079735109142e-05,4.78680428643910e-05,5.90190923781246e-05,7.14102057141040e-05,8.57168974376666e-05,0.000103203163088676,0.000123972119613532,0.000150434354524548,0.000182786227503236,0.000220708168326120,0.000270536677809036,0.000332813700897814,0.000418373867573865,0.000548732413339665,0.000762136834807654,0.00117647855665178,0.00235441856615387,0.0308290968488890,-0.00299199125514580,-0.00148506371000654,-0.00101380471036192,-0.000781497780255819,-0.000645273964186260,-0.000556046810930513,-0.000493877075158918,-0.000448523513854411,-0.000412303842299054,-0.000383077606631119,-0.000359824587541346,-0.000340987058602624,-0.000325727733969258,-0.000312634290136881,-0.000300665306370365,-0.000289845076032483,-0.000280078757572365,-0.000270815962595476,-0.000261714007754938,-0.000253196625592573,-0.000245408639075722,-0.000238471623451781,-0.000232479072125885,-0.000226592915191912,-0.000220360145267150,-0.000214318944080117,-0.000208729129441719,-0.000203618471233572,-0.000199024092617831,-0.000194512808790293,-0.000189726238628717,-0.000184920373150594,-0.000180395566592839];
            SL3 = [0, 0, -5.41169083363327e-06,1.93579945461191e-06,9.45415398436220e-06,1.72846681623942e-05,2.57298945842888e-05,3.51222086680498e-05,4.59178125797480e-05,5.89007537790749e-05,7.52056082357759e-05,9.64793609903237e-05,0.000125262590816173,0.000165063102146356,0.000221364178351084,0.000301460016846977,0.000417004465982483,0.000580411621327469,0.000796953704923743,0.00107059065710948,0.00126493230474523,0.00107504567899525,0.000432810288801775,-0.000182979979608244,-0.000505625913582457,-0.000631371255924270,-0.000665807931757958,-0.000669594881397634,-0.000657091878632299,-0.000638573502969134,-0.000638045339670189,-0.000637346459421282,-0.000636244957834837,-0.000641705600834923,-0.000665946937554838,-0.000709171667973235,-0.000736594965638038,-0.000782986899691775,-0.000884418917248520,-0.000934946038942086,-0.000967382341731840,-0.00102046357919877,-0.00107447012596335,-0.00114716078598103,-0.00119001729585532,-0.00116521866087739,-0.00110265325716526,-0.00107907022021372,-0.00105432002121941,-0.000986730258936408,-0.000898978019376415,-0.000820594016334917,-0.000745158146490135,-0.000675354820660815,-0.000620847123271931,-0.000576804237260839,-0.000536490442751615,-0.000501204647480799,-0.000473822144176810,-0.000452926241926594,-0.000432634172998229,-0.000412468709643994,-0.000398029399956267,-0.000395541163256905,-0.000388709942068372,-0.000387510554780465,-0.000394565648330784,-0.000401378681636353,-0.000409638886211242,-0.000419089691633886,-0.000427296144337625,-0.000440295692812109,-0.000444081665722617,-0.000448639924566298,-0.000440093649002209,-0.000424251880612064,-0.000384001796664408,-0.000328956461209000,-0.000293025322110392,-0.000278211145258338,-0.000295125199588672,-0.000331755081972902,-0.000382399669888867,-0.000458896661317541,-0.000561470322496374,-0.000651749198379864,-0.000713294193900586,-0.000774432946175471,-0.000777917790510983,-0.000626541118840483,-0.000331015030743759,2.63341736584166e-05,-0.000171992824937632,-0.000259817092239323,-0.000377470551110935,-0.000524934162394397,-0.000531619372566283,-0.000349649849915006,-0.000487762473325644,-0.000796912490538116,-0.000926015613904260,-0.00100911487456303,-0.000808971224386412,-0.000386087767047485,-0.000335941192162772,-0.000330147231955056,-0.000461625329698389,-0.000592930710649958,-0.000719657207956170,-0.00100986182892619,-0.000506689569217378,-0.000460010386257503,-0.000419079675076647,-0.000411658806109074,-0.000374167090433517,-0.000353651294940474,-0.000330524687637722,-0.000301916942489834,-0.000278679373311849,-0.000228633825844874,-0.000180214689346293,-0.000138499030302687,-0.000131256232555789,-0.000126670619695820,-0.000128549914972575,-0.000136599789799092,-0.000125634129293664,-0.000102398016114916,-9.85173405121720e-05,-9.96415211241822e-05,-0.000105954725980010,-0.000114196556649473,-0.000113196078296059,-0.000110434227104278,-0.000110116090417667,-0.000109662614915806,-0.000108926217276861,-0.000108834224371152,-0.000109417320427654,-0.000110643848702706,-0.000112994618012320,-0.000115441558404754,-0.000116548118491356,-0.000117483785344017,-0.000119085905517022,-0.000119254707708628,-0.000119215569527323,-0.000119579537026478,-0.000119375627988998,-0.000119371117231157,-0.000119859993749256,-0.000119309788975555,-0.000117876916959846,-0.000116218261416604,-0.000114624176964150,-0.000112348414294488,-0.000109768745562083,-0.000106671855381877,-0.000102824372078087,-9.95677618035209e-05,-9.70982221670803e-05,-9.66462454415062e-05,-9.87182372133061e-05,-0.000102477091016729,-0.000109658196663308,-0.000125820222893914,-0.000173258467809945,-0.00134538485253521,4.66369241780399e-05,-1.66430499113245e-05,-3.61713883967477e-05,-4.59240585783684e-05,-5.20667260001716e-05,-5.71185482844874e-05,-6.21046014443957e-05,-6.54445824261318e-05,-6.67723532437770e-05,-6.74275064363338e-05,-6.79067482361070e-05,-6.84437430598832e-05,-6.91945179398276e-05,-6.92862342221186e-05,-6.84472755623085e-05,-6.70953720150218e-05,-6.53705654684182e-05,-6.29657652243835e-05,-5.97453382707604e-05,-5.63111670525242e-05,-5.29328421944364e-05,-4.98235125768596e-05,-4.71544738259990e-05,-4.41462561761261e-05,-4.03286929798953e-05,-3.62096858805044e-05,-3.20521270696674e-05,-2.78707015652817e-05,-2.36840655764762e-05,-1.90401039562242e-05,-1.35484592486890e-05,-7.46145056748818e-06,-1.09242361201146e-06];
            varpi = (object.get_Theta(q(2))*200)/pi;
            varp = fix(varpi);
            if varp < 1
                varp = 2;
            end
            if varp > 199
                varp = 199;
            end
            sl1 = SL1(varp); sl2 = SL2(varp); sl3 = SL3(varp);
            
%             sl1 = object.SL(1, varp);
%             sl2 = object.SL(2, varp);
%             sl3 = object.SL(3, varp);
% 
%             u_eq = object.get_w(object.function_for_X(q(2)),q, epsilon) - ...
%                2000*object.saturation((sl1*epsilon(1) + sl2*epsilon(2) + sl3*epsilon(3)), 0.01);
            
            % CONTROLLER INPUT WITH U_EQ
            u = k*([k^-1 -1]*M*[object.get_dd_Theta(q(2))*dq(2)^2 + u_eq; 0] + ...
                [k^-1 -1]*C*[(object.get_d_Theta(q(2)))*dq(2) + epsilon(2); dq(2)]+[k^-1 -1]*G);                  

            % UNSTABLE TRAJECTORY
%             u = k*([k^-1 -1]*M*[object.get_dd_Theta(q(2))*dq(2)^2; 0] + ...
%                 [k^-1 -1]*C*[(object.get_d_Theta(q(2)))*dq(2); dq(2)]+[k^-1 -1]*G);

            % ORIGINAL LQR
%             u = k*([k^-1 -1]*M*[object.get_w(object.function_for_X(q(2)),q, epsilon) + ...
%                 object.get_dd_Theta(q(2))*dq(2)^2; 0] + [k^-1 -1]*C*[(object.get_d_Theta(q(2)))*dq(2) + ...
%                 epsilon(2); dq(2)]+[k^-1 -1]*G);
            
            
                      
        end

        function A_cl = find_Acl(object)
           K = @(x) -1/(object.Gamma)*object.B_transverse(x)'*object.function_for_X(x);
           A_cl = @(x) object.A_transverse(x) + K(x)*object.B_transverse(x);
        end
        function out = calc_stm(object)

            t_span = linspace(0, pi, 1000);
            x_0 = [1;0;0; 0;1;0; 0;0;1];

            [t, sol] = ode45(@(t, y) sim_stm(object, y, t), t_span, x_0);
            
            sol_out = [sol(100,1) sol(100,2) sol(100,3); ...
                sol(100,4) sol(100,5) sol(100,6); ...
                sol(100,7) sol(100,8) sol(100,9)];
            %disp('Out of solver');
            %disp(sol);
            
            %disp('Last element in sol');
            %disp(sol_out);
            
            %disp('F, sol/T');
            F_temp = sol_out/pi;
            %disp(F_temp);
            
            F = reshape(F_temp, 9, 1);
            [V, D] = eig(F_temp);
            %disp(V); disp(D);
            
            eig1 = V(:,1); eig2 = V(:,2); eig3 = V(:,3);
            %disp(eig1); disp(eig2); disp(eig3);
            
            eig_pair_1 = [reshape(eig2(:), 1, 3); reshape(eig3(:), 1, 3)];
            
            B = [0.0001;0.0001];
            S_hat = linsolve(eig_pair_1,B);
            disp('S_hat_pair_1');
            disp(S_hat);
            
            sol_inv_1 = 1:1:200;
            sol_inv_2 = 1:1:200;
            sol_inv_3 = 1:1:200;
            sol_inv_4 = 1:1:200;
            sol_inv_5 = 1:1:200;
            sol_inv_6 = 1:1:200;
            sol_inv_7 = 1:1:200;
            sol_inv_8 = 1:1:200;
            sol_inv_9 = 1:1:200;
            
            for i = 1:200
                L = [object.sol_1(i) object.sol_2(i) object.sol_3(i);
                    object.sol_4(i) object.sol_5(i) object.sol_6(i);
                    object.sol_7(i) object.sol_8(i) object.sol_9(i)];
                L_inv = inv(L);
                sol_inv_1(i) = L_inv(1,1);
                sol_inv_2(i) = L_inv(1,2);
                sol_inv_3(i) = L_inv(1,3);
                sol_inv_4(i) = L_inv(2,1);
                sol_inv_5(i) = L_inv(2,2);
                sol_inv_6(i) = L_inv(2,3);
                sol_inv_7(i) = L_inv(3,1);
                sol_inv_8(i) = L_inv(3,2);
                sol_inv_9(i) = L_inv(3,3);
            end
            
            S_L_1 = 1:1:200;
            S_L_2 = 1:1:200;
            S_L_3 = 1:1:200;
            B_L = 1:1:200;
            
            for i=1:200
                S_L_1(i) = S_hat(1)*sol_inv_1(i) + S_hat(2)*sol_inv_4(i) + S_hat(3)*sol_inv_7(i);
                S_L_2(i) = S_hat(1)*sol_inv_2(i) + S_hat(2)*sol_inv_5(i) + S_hat(3)*sol_inv_8(i);
                S_L_3(i) = S_hat(1)*sol_inv_3(i) + S_hat(2)*sol_inv_6(i) + S_hat(3)*sol_inv_9(i);
                varphi = (i/200)*pi;
                B_tr = object.B_transverse(varphi);
                B_L(i) = S_L_1(i)*B_tr(1) + S_L_2(i)*B_tr(2) + S_L_3(i)*B_tr(3);
            end
            
            time = linspace(0,pi,200);
            figure
            title('S-hat * L inv');
            hold on
            plot(time(:), S_L_1(:));
            plot(time(:), S_L_2(:));
            plot(time(:), S_L_3(:));
            hold off
            
            figure
            title('S-hat * B trans');
            plot(time(:), B_L(:));
            
            out = [reshape(S_L_1(:), 1,200); reshape(S_L_2(:), 1,200); reshape(S_L_3(:),1,200)];
        end   
        function out = sim_stm(object, x, time)
            disp(time);
            A = object.A_cl(time);
            A1 = ([1 0 0]*A)*[1;0;0];
            A2 = ([1 0 0]*A)*[0;1;0];
            A3 = ([1 0 0]*A)*[0;0;1];
            
            A4 = ([0 1 0]*A)*[1;0;0];
            A5 = ([0 1 0]*A)*[0;1;0];
            A6 = ([0 1 0]*A)*[0;0;1];
            
            A7 = ([0 0 1]*A)*[1;0;0];
            A8 = ([0 0 1]*A)*[0;1;0];
            A9 = ([0 0 1]*A)*[0;0;1];
            
            psi_1_dot = A1*x(1) + A2*x(4) + A3*x(7);
            psi_2_dot = A1*x(2) + A2*x(5) + A3*x(8);
            psi_3_dot = A1*x(3) + A2*x(6) + A3*x(9);
            
            psi_4_dot = A4*x(1) + A5*x(4) + A6*x(7);
            psi_5_dot = A4*x(2) + A5*x(5) + A6*x(8);
            psi_6_dot = A4*x(3) + A5*x(6) + A6*x(9);
            
            psi_7_dot = A7*x(1) + A8*x(4) + A9*x(7);
            psi_8_dot = A7*x(2) + A8*x(5) + A9*x(8);
            psi_9_dot = A7*x(3) + A8*x(6) + A9*x(9);
            
            out = [psi_1_dot; psi_2_dot; psi_3_dot; psi_4_dot; psi_5_dot; psi_6_dot; psi_7_dot; psi_8_dot; psi_9_dot];
            
            
        end
        
        function sol = find_FL_fac(object)
            
            st = linspace(0,pi,200);
            Yinit = reshape(eye(3),9,1);
            %F_0 = reshape(eye(3), [9,1]);
            
            F = [4.9858 -1.4536 -2.4591; ...
                4.4005 -1.1148 -2.2907; ...
                -13.1574 3.6607 6.6149];
            F0 = reshape(F, 9, 1);
            %F0 = reshape(eye(3),9,1);
            %F_0 = [1;1;1;1;1;1;1;1;1];
           
            
            solinit = bvpinit(st, @(x)([(sin(x)*Yinit + Yinit); F0]));
            %solinit = bvpinit(st, [F_0; F_0]);
            
            sol = bvp5c(@(s,Y)dBV(object,s,Y),@(Ya,Yb)resBV(object,Ya,Yb) ,solinit, bvpset('SingularTerm', 0.001*eye(18)));
            
            
            
       
            
            
%             x = linspace(0, pi, 200);
%             solinit = bvpinit(x, [1 0 0 0 1 0 0 0 1]);
%             sol = bvp4c(@object.ode, @object.bc, solinit);
            
            x_mesh = linspace(0,pi,200);
            figure
            hold on
            plot(x_mesh(:), sol.y(1,:));
            plot(x_mesh(:), sol.y(2,:));
            plot(x_mesh(:), sol.y(3,:));
            plot(x_mesh(:), sol.y(4,:));
            plot(x_mesh(:), sol.y(5,:));
            plot(x_mesh(:), sol.y(6,:));
            plot(x_mesh(:), sol.y(7,:));
            plot(x_mesh(:), sol.y(8,:));
            plot(x_mesh(:), sol.y(9,:));
            hold off
            sol = [sol.y(1,:); sol.y(2,:); sol.y(3,:); sol.y(4,:); sol.y(5,:); sol.y(6,:); sol.y(7,:); sol.y(8,:); sol.y(9,:)];
            
        end
        function dY = dBV(object,s,Y)
            
            disp(s);
%             F = [4.9858 -1.4536 -2.4591; ...
%                 4.4005 -1.1148 -2.2907; ...
%                 -13.1574 3.6607 6.6149];
            
%             A = object.A_cl;
%             A1 = ([1 0 0]*A(t))*[1;0;0];
%             A2 = @(t) ([1 0 0]*A(t))*[0;1;0];
%             A3 = @(t) ([1 0 0]*A(t))*[0;0;1];
%             
%             A4 = @(t) ([0 1 0]*A(t))*[1;0;0];
%             A5 = @(t) ([0 1 0]*A(t))*[0;1;0];
%             A6 = @(t) ([0 1 0]*A(t))*[0;0;1];
%             
%             A7 = @(t) ([0 0 1]*A(t))*[1;0;0];
%             A8 = @(t) ([0 0 1]*A(t))*[0;1;0];
%             A9 = @(t) ([0 0 1]*A(t))*[0;0;1];

            A1 = object.A1(s);
            A2 = object.A2(s);
            A3 = object.A3(s);
            A4 = object.A4(s);
            A5 = object.A5(s);
            A6 = object.A6(s);
            A7 = object.A7(s);
            A8 = object.A8(s);
            A9 = object.A9(s);
            
            Y1 = Y(1); 
            Y2 = Y(2);
            Y3 = Y(3);
            Y4 = Y(4);
            Y5 = Y(5);
            Y6 = Y(6);
            Y7 = Y(7);
            Y8 = Y(8);
            Y9 = Y(9);
            Y10 = Y(10);
            Y11 = Y(11);
            Y12 = Y(12);
            Y13 = Y(13);
            Y14 = Y(14);
            Y15 = Y(15);
            Y16 = Y(16);
            Y17 = Y(17);
            Y18 = Y(18);
            
%             L_1_dot = -(A1*Y1 + A4*Y2 + A7*Y3) + Y10*Y1 + Y11*Y4 + Y12*Y7;
%             L_2_dot = -(A2*Y1 + A5*Y2 + A8*Y3) + Y10*Y2 + Y11*Y5 + Y12*Y8;
%             L_3_dot = -(A3*Y1 + A6*Y2 + A9*Y3) + Y10*Y3 + Y11*Y6 + Y12*Y9;
%             
%             L_4_dot = -(A1*Y4 + A4*Y5 + A7*Y6) + Y13*Y1 + Y14*Y4 + Y15*Y7;
%             L_5_dot = -(A2*Y4 + A5*Y5 + A8*Y6) + Y13*Y2 + Y14*Y5 + Y15*Y8;
%             L_6_dot = -(A3*Y4 + A6*Y5 + A9*Y6) + Y13*Y3 + Y14*Y6 + Y15*Y9;
%             
%             L_7_dot = -(A1*Y7 + A4*Y8 + A7*Y9) + Y16*Y1 + Y17*Y4 + Y18*Y7;
%             L_8_dot = -(A2*Y7 + A5*Y8 + A8*Y9) + Y16*Y2 + Y17*Y5 + Y18*Y8;
%             L_9_dot = -(A3*Y7 + A6*Y8 + A9*Y9) + Y16*Y3 + Y17*Y6 + Y18*Y9;

            L_1_dot = A1*Y1 + A2*Y4 + A3*Y7 - (Y10*Y1 + Y13*Y2 + Y16*Y3);
            L_2_dot = A1*Y2 + A2*Y5 + A3*Y8 - (Y11*Y1 + Y14*Y2 + Y17*Y3);
            L_3_dot = A1*Y3 + A2*Y6 + A3*Y9 - (Y12*Y1 + Y15*Y2 + Y18*Y3);
            
            L_4_dot = A4*Y1 + A5*Y4 + A6*Y7 - (Y10*Y4 + Y13*Y5 + Y16*Y6);
            L_5_dot = A4*Y2 + A5*Y5 + A6*Y8 - (Y11*Y4 + Y14*Y5 + Y17*Y6);
            L_6_dot = A4*Y3 + A5*Y6 + A6*Y9 - (Y12*Y4 + Y15*Y5 + Y18*Y6);
            
            L_7_dot = A7*Y1 + A8*Y4 + A9*Y7 - (Y10*Y7 + Y13*Y8 + Y16*Y9);
            L_8_dot = A7*Y2 + A8*Y5 + A9*Y8 - (Y11*Y7 + Y14*Y8 + Y17*Y9);
            L_9_dot = A7*Y3 + A8*Y6 + A9*Y9 - (Y12*Y7 + Y15*Y8 + Y18*Y9);
            
            dL = [L_1_dot; L_2_dot; L_3_dot; L_4_dot; L_5_dot; L_6_dot; L_7_dot; L_8_dot; L_9_dot];
            disp(dL);
            
            dY = [dL; zeros(9,1)]; 
        end
        function res = resBV(object,Ya,Yb)    
            La = reshape(Ya(1:9),3,3);
            Lb = reshape(Yb(1:9),3,3);
            L_end = [28.2988 23.8833 -61.8193; 
                -0.5246 0.7272 1.1789; 
                -19.4342 -17.3820 45.6654];
            L_inv = inv(L_end);
            I = eye(3);
            res = [reshape((La - I), 9,1); reshape((Lb - L_inv), 9,1)];
        end
   
        function create_plots(object, input)

        %% dvarphi vs varphi
        figure
        hold on;
        %xlim([-pi/16 2*pi])
        xlim([-pi/16 4])
        ylim([0 8])
        plot(input.q.Data(:,2), input.dq.Data(:,2));
        %plot(input.q.Data(:,2), input.dphi_star.Data(:));
        plot(object.x_sim(:,1), object.x_sim(:,2));
        hold off
        
        % Control input
        figure
        hold on;
        xlim([-pi/16 4])
        ylim([-2 2])
        plot(input.u.Time(:), input.u.Data(:));
        plot(input.u_nom.Time(:), input.u_nom.Data(:));
        hold off
        
        % Error
        figure
        hold on
        plot(input.eps.Time(:), input.eps.Data(:,1));
        plot(input.eps.Time(:), input.eps.Data(:,2));
        plot(input.eps.Time(:), input.eps.Data(:,3));
        end
        function plot_nominal_feedback(object)
            time = linspace(0,pi,200);
            K1 = linspace(0,pi,200);
            K2 = linspace(0,pi,200);
            K3 = linspace(0,pi,200);
            for i = 1:length(time)
                w_vec = -1/(object.Gamma)*object.B_transverse(time(i))'*object.function_for_X(time(i));
                K1(i) = w_vec(1);
                K2(i) = w_vec(2);
                K3(i) = w_vec(3);
            end
            figure
            title('Nominal feedback K');
            hold on
            plot(time(:), K1(:));
            plot(time(:), K2(:));
            plot(time(:), K3(:));
            hold off
        end
        function plot_approx_of_stab_sol(object)
            tim = 0:0.01:2*pi;
                var1 = 0:0.01:2*pi;
                var2 = 0:0.01:2*pi;
                var3 = 0:0.01:2*pi;
                var4 = 0:0.01:2*pi;
                var5 = 0:0.01:2*pi;
                var6 = 0:0.01:2*pi;
                var7 = 0:0.01:2*pi;
                var8 = 0:0.01:2*pi;
                var9 = 0:0.01:2*pi;
                
                figure
                hold on
                
                for i = 1:length(tim)
                    in = (i/length(tim))*2*pi;
                    mat = object.function_for_X(in);
                    var1(i) = ([1 0 0]*mat)*[1;0;0];
                    var2(i) = ([1 0 0]*mat)*[0;1;0];
                    var3(i) = ([1 0 0]*mat)*[0;0;1];
                    var4(i) = ([0 1 0]*mat)*[1;0;0];
                    var5(i) = ([0 1 0]*mat)*[0;1;0];
                    var6(i) = ([0 1 0]*mat)*[0;0;1];
                    var7(i) = ([0 0 1]*mat)*[1;0;0];
                    var8(i) = ([0 0 1]*mat)*[0;1;0];
                    var9(i) = ([0 0 1]*mat)*[0;0;1];
                end
                
                plot(tim(:), var1(:));
                plot(tim(:), var2(:));
                plot(tim(:), var3(:));
                plot(tim(:), var4(:));
                plot(tim(:), var5(:));
                plot(tim(:), var6(:));
                plot(tim(:), var7(:));
                plot(tim(:), var8(:));
                plot(tim(:), var9(:));
                hold off
        end
       
    end
end
